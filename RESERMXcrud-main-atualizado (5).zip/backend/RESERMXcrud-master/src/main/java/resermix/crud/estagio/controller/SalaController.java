package resermix.crud.estagio.controller;
 
import resermix.crud.estagio.entity.Sala;
import resermix.crud.estagio.repository.SalaRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
 
@RestController
@RequestMapping("/salas")
public class SalaController {
 
    @Autowired
    private SalaRepository salaRepository;
 
    // ─── CREATE ──────────────────────────────────────────────────────────────────
 
    @PostMapping
    public ResponseEntity<Sala> cadastrarSala(@Valid @RequestBody Sala sala) {
        // Nova sala começa disponível por padrão
        if (sala.getDisponivel() == null) {
            sala.setDisponivel(true);
        }
        // Recursos não informados ficam como "não tem" (0 / false) em vez de NULL no banco
        sala.setTvs(sala.getTvs());
        sala.setComputadores(sala.getComputadores());
        sala.setArCondicionado(sala.getArCondicionado());
        sala.setDataShow(sala.getDataShow());
        Sala salva = salaRepository.save(sala);
        return ResponseEntity.ok(salva);
    }
 
    // ─── READ ─────────────────────────────────────────────────────────────────────
 
    @GetMapping
    public List<Sala> listarSalas() {
        return salaRepository.findAll();
    }
 
    @GetMapping("/{id}")
    public ResponseEntity<Sala> buscarSala(@PathVariable Long id) {
        return salaRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
 
    /**
     * Sem parâmetros: todas as salas liberadas (comportamento original).
     * Com data + horarioInicio + horarioFim: apenas as salas liberadas que
     * NÃO têm reserva ativa naquele período — uma sala já reservada nesse
     * horário deixa de aparecer na lista.
     */
    @GetMapping("/disponiveis")
    public ResponseEntity<?> listarSalasDisponiveis(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate data,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.TIME) LocalTime horarioInicio,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.TIME) LocalTime horarioFim) {

        boolean semFiltro = data == null && horarioInicio == null && horarioFim == null;
        if (semFiltro) {
            return ResponseEntity.ok(salaRepository.findByDisponivelTrue());
        }
        if (data == null || horarioInicio == null || horarioFim == null) {
            return ResponseEntity.badRequest()
                    .body("Informe data, horarioInicio e horarioFim juntos para filtrar por período.");
        }
        if (!horarioInicio.isBefore(horarioFim)) {
            return ResponseEntity.badRequest().body("O horário inicial deve ser anterior ao horário final.");
        }
        return ResponseEntity.ok(salaRepository.buscarDisponiveisNoPeriodo(data, horarioInicio, horarioFim));
    }
 
    // ─── UPDATE ───────────────────────────────────────────────────────────────────
 
    @PutMapping("/{id}")
    public ResponseEntity<Sala> editarSala(@PathVariable Long id, @Valid @RequestBody Sala salaAtualizada) {
        return salaRepository.findById(id).map(sala -> {
            sala.setName(salaAtualizada.getName());
            sala.setCapacidade(salaAtualizada.getCapacidade());
            sala.setDisponivel(salaAtualizada.getDisponivel());
            sala.setTvs(salaAtualizada.getTvs());
            sala.setComputadores(salaAtualizada.getComputadores());
            sala.setArCondicionado(salaAtualizada.getArCondicionado());
            sala.setDataShow(salaAtualizada.getDataShow());
            return ResponseEntity.ok(salaRepository.save(sala));
        }).orElse(ResponseEntity.notFound().build());
    }
 
    // ─── Alterar status (bloquearSala / liberarSala) ──────────────────────────────
 
    @PatchMapping("/{id}/status")
    public ResponseEntity<Sala> alterarStatus(@PathVariable Long id,
                                               @RequestParam Boolean disponivel) {
        return salaRepository.findById(id).map(sala -> {
            sala.alterarStatus(disponivel);
            return ResponseEntity.ok(salaRepository.save(sala));
        }).orElse(ResponseEntity.notFound().build());
    }
 
    // ─── DELETE ───────────────────────────────────────────────────────────────────
 
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletarSala(@PathVariable Long id) {
        if (!salaRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        salaRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}