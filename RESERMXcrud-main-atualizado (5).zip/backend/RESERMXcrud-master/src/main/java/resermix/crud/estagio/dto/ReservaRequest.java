package resermix.crud.estagio.dto;

import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 * DTO de entrada para criação/edição de reservas.
 *
 * Recebemos apenas os IDs de usuário e sala (em vez da entidade completa)
 * para evitar acoplamento com a serialização polimórfica de Usuario e para
 * deixar explícito, na própria API, quais campos o cliente deve enviar.
 */
public class ReservaRequest {

    @NotNull(message = "O usuário responsável pela reserva é obrigatório.")
    private Long usuarioId;

    @NotNull(message = "A sala é obrigatória.")
    private Long salaId;

    @NotNull(message = "A data da reserva é obrigatória.")
    private LocalDate data;

    @NotNull(message = "O horário inicial é obrigatório.")
    private LocalTime horarioInicio;

    @NotNull(message = "O horário final é obrigatório.")
    private LocalTime horarioFim;

    private String observacao;

    public Long getUsuarioId() { return usuarioId; }
    public void setUsuarioId(Long usuarioId) { this.usuarioId = usuarioId; }

    public Long getSalaId() { return salaId; }
    public void setSalaId(Long salaId) { this.salaId = salaId; }

    public LocalDate getData() { return data; }
    public void setData(LocalDate data) { this.data = data; }

    public LocalTime getHorarioInicio() { return horarioInicio; }
    public void setHorarioInicio(LocalTime horarioInicio) { this.horarioInicio = horarioInicio; }

    public LocalTime getHorarioFim() { return horarioFim; }
    public void setHorarioFim(LocalTime horarioFim) { this.horarioFim = horarioFim; }

    public String getObservacao() { return observacao; }
    public void setObservacao(String observacao) { this.observacao = observacao; }
}
