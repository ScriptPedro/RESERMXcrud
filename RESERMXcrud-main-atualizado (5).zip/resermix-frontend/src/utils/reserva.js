// Mapeia o enum StatusReserva do backend para rótulo e classe CSS do badge.
export const STATUS_INFO = {
  PENDENTE: { texto: 'Pendente', classe: 'pendente' },
  CONFIRMADA: { texto: 'Confirmada', classe: 'confirmada' },
  EM_ANDAMENTO: { texto: 'Em andamento', classe: 'andamento' },
  FINALIZADA: { texto: 'Finalizada', classe: 'finalizada' },
  CANCELADA: { texto: 'Cancelada', classe: 'cancelada' },
};

export function statusInfo(status) {
  return STATUS_INFO[status] || { texto: status || '—', classe: '' };
}

// dd/mm/aaaa a partir de "aaaa-mm-dd"
export function formatarData(data) {
  if (!data) return '—';
  const [ano, mes, dia] = data.split('-');
  return `${dia}/${mes}/${ano}`;
}

// HH:mm a partir de "HH:mm:ss"
export function formatarHora(hora) {
  if (!hora) return '—';
  return hora.slice(0, 5);
}
